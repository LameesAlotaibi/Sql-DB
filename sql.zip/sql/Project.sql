use db2;
insert into company( Co_ID,Co_Name,co_Email, co_Location)
values("2002","Limitless","Limitless@coffee.com","riyadh");
insert into warehouse( wareHouse_id, wareHouse_Location, Storage_space,company_Co_ID)
values("111","riyadh","100m","2002");
insert into warehouse( wareHouse_id, wareHouse_Location, Storage_space,company_Co_ID)
values("222","riyadh","200","2002");
insert into warehouse( wareHouse_id, wareHouse_Location, Storage_space,company_Co_ID)
values("333","riyadh","300","2002");
select * from warehouse;
insert into Product(  Product_ID, product_name,  P_description,  warehouse_wareHouse_id)
values("11", "Ethobia","medium roasts","111");

insert into Product(  Product_ID, product_name,  P_description,  warehouse_wareHouse_id)
values("222", "Colombia","light roasts","222");
insert into Product(  Product_ID, product_name,  P_description,  warehouse_wareHouse_id)
values("333", "Brazil","dark roasts","333");
select * from Product;
insert into supplier (Supplier_ID,Supplier_Name,  Product_Type,  Location, warehouse_wareHouse_id)
values ("45" , "Raoom" , "Ethobia","Dammam" ,"111");

insert into supplier (Supplier_ID,Supplier_Name,  Product_Type,  Location, warehouse_wareHouse_id)
values ("46" , "Lamees" , "Colombia","jeddah" ,"222");
insert into supplier (Supplier_ID,Supplier_Name,  Product_Type,  Location, warehouse_wareHouse_id)
values ("47" , "wajd" , "Brazil","taif" ,"333");
select * from supplier;
insert into Orders (orderid,Date,Status )
values ("11" , "2021-02-15","arrived");
insert into Orders (orderid, Date ,Status )
values ("12" , "2020-05-15","on the way");
insert into Orders (orderid, Date ,Status )
values ("13" , "2020-12-09","on the way");
insert into Orders (orderid, Date ,Status )
values ("14" , "2022-09-15","arrived");
insert into Orders (orderid, Date ,Status )
values ("15" , "2021-10-01","arrived");
insert into Orders (orderid, Date ,Status )
values ("16" , "2020-05-22","on the way");
select * from orders;

insert into customer (Customer_id , customer_Name , Location , Payment)
values ("1234" , "Abdurhman" , "Al-madinah" , "Cash" );
insert into customer (Customer_id , customer_Name , Location , Payment)
values ("2345" , "Wajd" , "AlKhobar" , "Cash" );
insert into customer (Customer_id , customer_Name , Location , Payment)
values ("3345" , "Mashael" , "Jeddah" , "Credit Card" );
insert into customer (Customer_id , customer_Name , Location , Payment)
values ("4345" , "Lamees" , "Jeddah" , "Cash" );
insert into customer (Customer_id , customer_Name , Location , Payment)
values ("5345" , "sara" , "Jeddah" , "Cash" );
insert into customer (Customer_id , customer_Name , Location , Payment)
values ("6345" , "jouri" , "Jeddah" , "Credit Card" );
select * from customer;